
  # COOP Website

  This is a code bundle for COOP Website. The original project is available at https://www.figma.com/design/l2Pby9XFSGkq5VM2kb1rz5/COOP-Website.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  